a = inputValue[0]
b = inputValue[1]
c = inputValue[2]

if (b <= a <= c) or (c <= a <= b):result = a

elif (a <= b <= c) or (c <= b <= a):result = b

else:result = a

outputTC = result